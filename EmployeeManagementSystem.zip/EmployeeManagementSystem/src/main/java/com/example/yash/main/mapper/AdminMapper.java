package com.example.yash.main.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import com.example.yash.main.model.Admin;

public class AdminMapper implements RowMapper<Admin>
{

	@Override
	public Admin mapRow(ResultSet rs, int rowNum) throws SQLException {
		Admin a1=new Admin();
        a1.setUsername(rs.getString("username"));
		a1.setPassword(rs.getString("password"));
		a1.setEmail(rs.getString("email"));
		return a1;
	}

}
