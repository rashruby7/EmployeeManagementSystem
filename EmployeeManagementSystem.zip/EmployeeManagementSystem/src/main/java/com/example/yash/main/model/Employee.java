package com.example.yash.main.model;

public class Employee 
{
	

}
