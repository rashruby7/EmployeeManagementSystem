package com.example.yash.main.service;

import java.util.List;

import com.example.yash.main.model.Admin;

public interface AdminService 
{
	public List<Admin> findAllAdmin();
	

}
