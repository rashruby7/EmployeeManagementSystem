package com.example.yash.main.repository;

import java.util.List;

import com.example.yash.main.model.Admin;

public interface AdminRepository 
{	
     public List<Admin> findAllAdmin();
}
