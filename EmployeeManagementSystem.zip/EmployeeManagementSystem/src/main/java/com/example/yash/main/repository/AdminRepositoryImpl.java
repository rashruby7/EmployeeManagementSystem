package com.example.yash.main.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.yash.main.mapper.AdminMapper;
import com.example.yash.main.model.Admin;

@Repository
public class AdminRepositoryImpl implements AdminRepository
{
	@Autowired
	JdbcTemplate jdbctemplate;

	@Override
	public List<Admin> findAllAdmin() {
		String sql="select * from admin";
		return jdbctemplate.query(sql, new AdminMapper());
	}

	

}
